# DevHelper Code Analysis - Browser Extension

🔍 Браузерний екстеншен для аналізу невикористаного коду в проектах

## ✨ Можливості

- 🎨 Аналіз невикористаних CSS класів
- ⚡ Пошук невикористаних JavaScript функцій
- 📦 Виявлення невикористаних змінних
- 🖼️ Знаходження невикористаних зображень
- 🔄 Пошук дублікатів функцій
- 🌐 Аналіз API роутів (Next.js, Express, Fetch, Axios)
- 📄 Визначення типу проекту та фреймворку
- 📊 Аналіз архітектури проекту
- 🔍 TypeScript типи та їх використання

## 🚀 Швидкий старт

### 1. Встановлення

```bash
# Відкрий Chrome/Edge
# Перейди в chrome://extensions/
# Увімкни "Режим розробника"
# Натисни "Завантажити розпаковане розширення"
# Вибери папку extension/
```

### 2. Використання

1. Натисни на іконку екстеншена
2. Вибери ZIP архів свого проекту
3. Дочекайся результатів аналізу
4. Переглядай детальну інформацію

## 📁 Структура проекту

```
extension/
├── components/              # Модульні компоненти
│   ├── utils.js            # Базові утиліти
│   ├── analyzers.js        # Аналізатори коду
│   ├── api-analyzer.js     # Аналіз API
│   ├── zip-handler.js      # Робота з ZIP
│   ├── ui-renderer.js      # Рендеринг UI
│   └── README.md           # Документація компонентів
│
├── lib/                    # Бібліотеки
│   └── jszip.min.js       # ZIP бібліотека
│
├── icons/                  # Іконки
├── popup.html             # HTML інтерфейс
├── popup-main.js          # Головний контролер
├── styles.css             # Стилі
└── manifest.json          # Конфігурація

Документація/
├── README.md                   # Цей файл
├── GETTING_STARTED.md          # Швидкий старт
├── QUICK_REFERENCE.md          # Довідник API
├── COMPONENT_STRUCTURE.md      # Структура компонентів
└── ARCHITECTURE.md             # Архітектура
```

## 📚 Документація

- **[GETTING_STARTED.md](GETTING_STARTED.md)** - Швидкий старт за 5 хвилин
- **[QUICK_REFERENCE.md](QUICK_REFERENCE.md)** - Приклади використання API
- **[COMPONENT_STRUCTURE.md](COMPONENT_STRUCTURE.md)** - Структура компонентів
- **[ARCHITECTURE.md](ARCHITECTURE.md)** - Архітектура проекту
- **[components/README.md](components/README.md)** - Документація компонентів

## 🛠️ Технології

- **Vanilla JavaScript** - без фреймворків
- **Модульна архітектура** - без ES6 імпортів (для сумісності з браузерами)
- **Глобальні namespace** - `window.Analyzers`, `window.ZipHandler` тощо
- **JSZip** - для роботи з ZIP файлами
- **Manifest V3** - нова версія Chrome Extensions API

## 🎯 Підтримувані фреймворки

- ✅ React (CRA, Vite)
- ✅ Next.js (App Router, Pages Router)
- ✅ Vue.js
- ✅ Nuxt
- ✅ Angular
- ✅ Svelte

## 💡 Приклади використання

### Аналіз CSS класів

```javascript
const cssResult = window.Analyzers.analyzeCSSClasses(cssFiles, jsFiles);
console.log("Unused CSS:", cssResult.unused);
```

### Аналіз функцій

```javascript
const funcResult = window.Analyzers.analyzeFunctions(jsFiles);
console.log("Unused functions:", funcResult.unused);
```

### Повний аналіз проекту

```javascript
const result = await window.ZipHandler.analyzeZipProject(dataView);
console.log("Project analysis:", result);
```

Більше прикладів в [QUICK_REFERENCE.md](QUICK_REFERENCE.md)

## 🔧 Розробка

### Додати новий аналізатор

```javascript
// В components/analyzers.js
window.Analyzers.myAnalyzer = function (files) {
  // твоя логіка
  return results;
};
```

### Додати новий UI блок

```javascript
// В components/ui-renderer.js
window.UIRenderer.renderMyBlock = function (data) {
  return "<div>" + data + "</div>";
};
```

Детальніше в [COMPONENT_STRUCTURE.md](COMPONENT_STRUCTURE.md)

## 📊 Статистика

- **5 модульних компонентів** - чітка структура
- **8 типів аналізу** - комплексний підхід
- **4 документи** - необхідна інформація
- **Без зайвих файлів** - тільки важливе

## 🎉 Переваги модульної структури

- ✅ **Модульність** - легко знайти потрібний код
- ✅ **Читабельність** - зрозуміла організація
- ✅ **Підтримка** - зміни ізольовані
- ✅ **Розширюваність** - легко додавати функції
- ✅ **Сумісність** - працює без збірки

## 🤝 Внесок

1. Fork проекту
2. Створи feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit зміни (`git commit -m 'Add some AmazingFeature'`)
4. Push в branch (`git push origin feature/AmazingFeature`)
5. Відкрий Pull Request

## 📝 Ліцензія

Цей проект ліцензовано під MIT License

## 📞 Підтримка

- 📖 Документація: [README.md](README.md)
- 🚀 Швидкий старт: [GETTING_STARTED.md](GETTING_STARTED.md)
- 💡 Приклади: [QUICK_REFERENCE.md](QUICK_REFERENCE.md)
- 🏗️ Архітектура: [ARCHITECTURE.md](ARCHITECTURE.md)

---

**Версія**: 1.0.0  
**Дата**: 31 грудня 2024  
**Статус**: ✅ Готово до використання
